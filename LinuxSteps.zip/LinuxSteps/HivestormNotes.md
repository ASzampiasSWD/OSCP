# UCF Hivestorm Linux Battle File
<pre>
<b style="color: red">DO NOT SHARE outside of UCF.</b>
Credits: Amanda, Gavin, Ravy, and Martin.
Want to add on? - Message Amanda in Discord.
Goals: Find more Easter Eggs to collect. What do we NOT have?
Sourque '21: https://sourque.com/ctf/hivestorm/hs21/
Sourque '20: https://sourque.com/ctf/hivestorm/hs20/
</pre>

# Forensic Questions
<pre>
sudo grep -irl ".m4b" /home   (i=case-insensitive, r=recursive, l=by file)
cd /home; ls *
sudo find . -name AesopsFables64kbps_librivox.m4b
sudo find /home -name *.jpg
“lbkid” or “lsblk” command or something like “ls -l /dev/disk/by-uuid”
Take a Screenshot of the Forensic Questions After. In case you need to reset the box. 
</pre>

# Backups
<pre>
mkdir /backups
tar -czf "/backups/etc-$(date).tar.gz" /etc
tar -czf "/backups/var-www-$(date).tar.gz" /var/www
</pre>

# APT/APT-GET Section
<pre>
1. APT has been updated | Samba has been updated | Firefox has been updated
Update software for points. sudo apt-get install firefox --only-upgrade

<b>1. Update /etc/apt/sources.list first.</b>
2. Then sudo apt-get update && sudo apt-get upgrade.
Be careful of sudo apt-get upgrade. Execute it at the beginning so you can revert the box if needed. After the forensic questions.

Fix /etc/apt/sources.list  (Look at /etc/apt/sources.list/d for malicious entries too.)
https://mirrors.ustc.edu.cn/repogen/ <- Check this out.
deb http://security.ubuntu.com/ubuntu/ trusty-security universe main multiverse restricted
deb http://security.ubuntu.com/ubuntu xenial-security main restricted
deb-src http://security.ubuntu.com/ubuntu xenial-security universe
deb-src http://security.ubuntu.com/ubuntu xenial-security multiverse

3. Automatically check for updates daily
ratchet@ubuntu:/etc/apt/apt.conf.d$ cat 10periodic 
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Download-Upgradeable-Packages "1";
APT::Periodic::AutocleanInterval "1";
APT::Periodic::Unattended-Upgrade "1";
</pre>

# Remove Unnecessary Programs and Files Section
<pre>
1. Remove Unnecessary Programs
Use the programs.txt and find_prohibited_programs.sh to search for programs.
<b>find_prohibited_programs.sh</b> <a href="https://drive.google.com/file/d/14cZ5CVcRFsHtULIjdO1brtoDCLI9KgbO/view?usp=sharing">Google Drive find_prohibited_programs.sh</a>
<b>programs.txt</b> <a href="https://drive.google.com/file/d/1ZzSGHCvpv07SPIxOHFMPXL54_luw-fC5/view?usp=sharing">Google Drive programs.txt</a>
Maybe don't use purge if you need to bring it back from the dead.  
sudo apt-get remove samba
sudo purge samba

<b>Programs:</b>
aircrack
aircrack-ng
as
apache2
bind9
bloodhound
bluez*
burpsuite
cadaver
cc
cewl
crackmapexec
crunch
dsniff
dmitry
exim4
exim4-base
exim4-config
exim4-daemon-light
fcrackzip
freeciv
ftp
g++
g++-5
gcc
gcc-5
go
gware
hashcat
hydra
hydra-gtk
ike-scan
inetd
ircd
irpas
john
john-data
johntheripper
kismet
lcrack
legion
linpeas.sh
logkeys
make
mariadb
medusa
mimikatz
minetest
msfconsole
msfvenom
nasm
nc
ncrack
netcat
netdiscover
nfs
nginx
nikto
nmap
openarena
ophcrack
ophcrack-cli
owl-shell
pdfcrack
postfix
proftpd
pureftpd
pyrit
rarcrack
recon-ng
remmina
remmina-common
remote-login-service
responder
rfdump
sane-utils
searchsploit
shell.elf
shell.sh
sipcrack
skipfish
snmp
spiderfoot
sqlmap
telnet
unix-privesc-check
vino
vnc
wireshark
wpscan
zeitgeist
zenmap

#!/bin/bash
if [ "$EUID" -ne 0 ]
  then echo "Please run as sudo"
  exit
fi


while IFS= read -r line; do
  if [ $1 -eq 1 ]
  then
    result=$(apt list --installed 2>/dev/null | grep -i "$line" | wc -l) 
    if [ $result -gt 0 ]
    then
      echo $line "+ - - - - - - - +" $result
    fi
  fi
  if [ $1 -eq 2 ]
  then
    result=$(locate -i 2>/dev/null "$line" | wc -l)
    if [ $result -gt 0 ]
    then
      echo $line "+ - - - - - - - +" $result
    fi
  fi
  if [ $1 -eq 3 ]
  then
    result=$(find / -iname "$line" 2>/dev/null | wc -l)
    if [ $result -gt 0 ]
    then
      echo $line "+ - - - - - - - +" $result
    fi
  fi    
done < "programs.txt"



2. Remove Unnecessary Files (not business related)
<b>find_prohibited_files.sh</b> <a href="https://drive.google.com/file/d/1fUNjlsy7HT9_6fpFfTK4Hc0XNCsxtDUa/view?usp=sharing">Google Drive find_prohibited_files.sh</a>

#!/bin/bash
# Remove Prohibited Files on a Business Computer.

fileName="prohibitedFiles.txt"
if [ -z "$1" ]
  then
    echo "No argument supplied. Please run ./find_prohibited_files.sh / OR ./find_prohibited_files /home instead."
	exit
fi

if [ "$EUID" -ne 0 ]
  then echo "Please run as sudo"
  exit
fi


find $1 -name "*.midi" -type f >> ~/Documents/$fileName
find $1 -name "*.mid" -type f >> ~/Documents/$fileName
find $1 -name "*.mod" -type f >> ~/Documents/$fileName
find $1 -name "*.mp3" -type f >> ~/Documents/$fileName
find $1 -name "*.mp2" -type f >> ~/Documents/$fileName
find $1 -name "*.mpa" -type f >> ~/Documents/$fileName
find $1 -name "*.abs" -type f >> ~/Documents/$fileName
find $1 -name "*.mpega" -type f >> ~/Documents/$fileName
find $1 -name "*.au" -type f >> ~/Documents/$fileName
find $1 -name "*.snd" -type f >> ~/Documents/$fileName
find $1 -name "*.wav" -type f >> ~/Documents/$fileName
find $1 -name "*.aiff" -type f >> ~/Documents/$fileName
find $1 -name "*.aif" -type f >> ~/Documents/$fileName
find $1 -name "*.sid" -type f >> ~/Documents/$fileName
find $1 -name "*.flac" -type f >> ~/Documents/$fileName
find $1 -name "*.ogg" -type f >> ~/Documents/$fileName
echo "All audio files has been listed."

find $1 -name "*.mpeg" -type f >> ~/Documents/$fileName
find $1 -name "*.mpg" -type f >> ~/Documents/$fileName
find $1 -name "*.mpe" -type f >> ~/Documents/$fileName
find $1 -name "*.dl" -type f >> ~/Documents/$fileName
find $1 -name "*.movie" -type f >> ~/Documents/$fileName
find $1 -name "*.movi" -type f >> ~/Documents/$fileName
find $1 -name "*.mv" -type f >> ~/Documents/$fileName
find $1 -name "*.iff" -type f >> ~/Documents/$fileName
find $1 -name "*.anim5" -type f >> ~/Documents/$fileName
find $1 -name "*.anim3" -type f >> ~/Documents/$fileName
find $1 -name "*.anim7" -type f >> ~/Documents/$fileName
find $1 -name "*.avi" -type f >> ~/Documents/$fileName
find $1 -name "*.vfw" -type f >> ~/Documents/$fileName
find $1 -name "*.avx" -type f >> ~/Documents/$fileName
find $1 -name "*.fli" -type f >> ~/Documents/$fileName
find $1 -name "*.flc" -type f >> ~/Documents/$fileName
find $1 -name "*.mov" -type f >> ~/Documents/$fileName
find $1 -name "*.qt" -type f >> ~/Documents/$fileName
find $1 -name "*.spl" -type f >> ~/Documents/$fileName
find $1 -name "*.swf" -type f >> ~/Documents/$fileName
find $1 -name "*.dcr" -type f >> ~/Documents/$fileName
find $1 -name "*.dir" -type f >> ~/Documents/$fileName
find $1 -name "*.dxr" -type f >> ~/Documents/$fileName
find $1 -name "*.rpm" -type f >> ~/Documents/$fileName
find $1 -name "*.rm" -type f >> ~/Documents/$fileName
find $1 -name "*.smi" -type f >> ~/Documents/$fileName
find $1 -name "*.ra" -type f >> ~/Documents/$fileName
find $1 -name "*.ram" -type f >> ~/Documents/$fileName
find $1 -name "*.rv" -type f >> ~/Documents/$fileName
find $1 -name "*.wmv" -type f >> ~/Documents/$fileName
find $1 -name "*.asf" -type f >> ~/Documents/$fileName
find $1 -name "*.asx" -type f >> ~/Documents/$fileName
find $1 -name "*.wma" -type f >> ~/Documents/$fileName
find $1 -name "*.wax" -type f >> ~/Documents/$fileName
find $1 -name "*.wmv" -type f >> ~/Documents/$fileName
find $1 -name "*.wmx" -type f >> ~/Documents/$fileName
find $1 -name "*.3gp" -type f >> ~/Documents/$fileName
find $1 -name "*.mov" -type f >> ~/Documents/$fileName
find $1 -name "*.mp4" -type f >> ~/Documents/$fileName
find $1 -name "*.avi" -type f >> ~/Documents/$fileName
find $1 -name "*.swf" -type f >> ~/Documents/$fileName
find $1 -name "*.flv" -type f >> ~/Documents/$fileName
find $1 -name "*.m4v" -type f >> ~/Documents/$fileName
echo "All video files have been listed."

find $1 -name "*.tiff" -type f >> ~/Documents/$fileName
find $1 -name "*.tif" -type f >> ~/Documents/$fileName
find $1 -name "*.rs" -type f >> ~/Documents/$fileName
find $1 -name "*.im1" -type f >> ~/Documents/$fileName
find $1 -name "*.gif" -type f >> ~/Documents/$fileName
find $1 -name "*.jpeg" -type f >> ~/Documents/$fileName
find $1 -name "*.jpg" -type f >> ~/Documents/$fileName
find $1 -name "*.jpe" -type f >> ~/Documents/$fileName
find $1 -name "*.png" -type f >> ~/Documents/$fileName
find $1 -name "*.rgb" -type f >> ~/Documents/$fileName
find $1 -name "*.xwd" -type f >> ~/Documents/$fileName
find $1 -name "*.xpm" -type f >> ~/Documents/$fileName
find $1 -name "*.ppm" -type f >> ~/Documents/$fileName
find $1 -name "*.pbm" -type f >> ~/Documents/$fileName
find $1 -name "*.pgm" -type f >> ~/Documents/$fileName
find $1 -name "*.pcx" -type f >> ~/Documents/$fileName
find $1 -name "*.ico" -type f >> ~/Documents/$fileName
find $1 -name "*.svg" -type f >> ~/Documents/$fileName
find $1 -name "*.svgz" -type f >> ~/Documents/$fileName
echo "All image files have been listed."


find $1 -name "*.m4b" -type f >> ~/Documents/$fileName
echo "All audiobook files have been listed."

echo "File Logs Located In: ~/Documents/$fileName" 

</pre>

# PAM Password Policy Section /etc/pam.d
<pre>
1. Create Password Policy
View Password Policy doc: https://docs.google.com/document/d/1yAiBuiQqYci0FTy1iklKNm4F9RZxtpT4/edit

2. Disallow Null Password Authentication 
https://www.cyberciti.biz/tips/linux-or-unix-disable-null-passwords.html

common-auth | common-password 
sudo grep -nr "nullok" /etc/pam.d/ 2>/dev/null
pam_unix.so nullok obscure min=4 max=8 sha512 (change this if its md5, ty Gavin)
Remove nullok.
</pre>

# Firewall Section
<pre>
1. Enable UFW Firewall Protection
Set IPv6 to no in /etc/default/ufw 
Set ICMP to DROP in /etc/ufw/before.rules
sudo systemctl start ufw
sudo ufw reset
sudo ufw logging high
sudo ufw default deny incoming
sudo ufw default deny outgoing 
sudo ufw allow out 53
sudo ufw allow out http
sudo ufw allow out https
sudo ufw allow 22 (NOTE: Whatever the required service is, change this)
sudo ufw enable
</pre>

<b><u>Scorebot is on port OUT HTTPS 443.</u></b>

# User Section
<pre>
1. Change root password
sudo passwd root

2. Lock root Account
passwd -l root
chage -E0 root

3. Make sure the UID and GID of 0 exist for only root
id 0
cat /etc/passwd | grep 0:0

4. Remove Unauthorized Users from sudo group
cat /etc/group | grep sudo 
sudo gpasswd -d qwark sudo
sudo gpasswd -d tapogee sudo

5. Add Authorized Users to sudo group if missing
cat /etc/group | grep sudo 
sudo usermod -aG sudo cynthia

6. Delete Users who are not in the README.md
deluser evilhacker

7. Delete Hidden Users (/home/evilhacker)
rm -R /home/evilhacker 
deluser evilhacker

8. Add Users who are in the README.md but NOT in /etc/passwd
adduser cynthia

9. Update User Passwords
sudo passwd qwark (manual). Script Process below.
</pre>
<pre>
#!/bin/bash
# Gavin Script
myuser="admin" #put the name of the admin user here
touch txt.txt; getent passwd {1000..60000} | cut -d: -f1 > txt.txt

#get all users but the myuser
systemUsersTrimmed=$(grep -vw "$myuser" txt.txt)
readarray -t systemUsersTrimmedArr <<<"$systemUsersTrimmed"

#set all the user passwords
for user in "${systemUsersTrimmedArr[@]}"; do
    echo "$user":"Sup3r5tr0ngP@55W0rd" | chpasswd
    chage -M 60 -m 10 -W 7 "$user"
done
</pre>
<pre>
10. Disable Shell Login for Users who shouldn't have bash (Example: irc, mail, news)
cat /etc/passwd | grep -i "/bin/bash" AND "/bin/sh" AND "/bin/zsh" etc
Change to /usr/sbin/nologin using vim /etc/passwd
</pre>

# SYSCTL Section /etc/sysctl.conf 
<pre>
<b>run_sysctl_fix.sh </b><a href="https://drive.google.com/file/d/154KZTFizXUALVu2WztxUlDo2iS-AyqZD/view?usp=sharing">Google Drive run_sysctl_fix.sh</a>
Execute this file. After run: cat run_sysctl_fix.sh | awk -F '-w' {' print $2 '} | awk NF
Save input to /etc/sysctl.conf. <b>BELOW</b>

#!/bin/bash
# Run as sudo ./run_sysctl_fix.sh.
# cat run_sysctl_fix.sh | awk -F '-w' {' print $2 '} | awk NF (save this to /etc/sysctl.conf)
echo Making a Copy of /etc/sysctl.conf in /tmp/systl.conf
cp /etc/sysctl.conf /tmp/sysctl.conf
###### Gavin List ######
sysctl -w net.ipv4.icmp_ignore_bogus_error_responses=1
sysctl -w net.ipv4.icmp_echo_ignore_broadcasts=1
# Ignore Broadcast ICMP Echo Requests			
sysctl -w net.ipv4.icmp_echo_ignore_all=1	
# Prevent Spoofing Attacks
sysctl -w net.ipv4.conf.all.rp_filter=1
sysctl -w net.ipv4.conf.default.rp_filter=1
# Do not accept IP source route packets (we are not a router)
sysctl -w net.ipv4.conf.all.accept_source_route=0
sysctl -w net.ipv4.conf.default.accept_source_route=0
sysctl -w net.ipv4.conf.default.send_redirects=0 
sysctl -w net.ipv4.conf.all.send_redirects=0
# Turn on TCP SYN Cookie Protection
sysctl -w net.ipv4.tcp_syncookies=1
sysctl -w net.ipv4.tcp_synack_retries=2
# Accept ICMP redirects only for gateways listed in our default GW list
sysctl -w net.ipv4.conf.all.secure_redirects=0 				
sysctl -w net.ipv4.conf.default.secure_redirects=0
# Logging of Martian Packets Enabled
sysctl -w net.ipv4.conf.all.log_martians=1
sysctl -w net.ipv4.conf.default.log_martians=1
# Do not accept ICMP Redirects
sysctl -w net.ipv4.conf.default.accept_redirects=0			
sysctl -w net.ipv4.conf.all.accept_redirects=0
sysctl -w net.ipv6.conf.all.disable_ipv6=1
sysctl -w net.ipv6.conf.default.disable_ipv6=1
sysctl -w net.ipv6.conf.lo.disable_ipv6=1
sysctl -w net.ipv6.conf.ens33.disable_ipv6=1
sysctl -w net.ipv6.conf.all.accept_ra=0
sysctl -w net.ipv6.conf.default.accept_ra=0
sysctl -w net.ipv6.conf.all.accept_redirects=0 
sysctl -w net.ipv6.conf.default.accept_redirects=0
###### Gavin List ######
# Amanda Add-On
# Restrict Unprivileged Access to Kernel Syslog
sysctl -w kernel.dmesg_restrict=1
# Assassination 
sysctl -w net.ipv4.tcp_rfc1337=1
# Reload
sysctl -p
</pre>

# LIGHTDM Section /etc/lightdm/lightdm.conf
<pre>
1. Disable Enumeration of System Users.
2. Disable guest account.

echo "
autologin-guest=false
autologin-user=NONE
allow-guest = false
greeter-hide-users=true
greeter-allow-guest=false
greeter-show-manual-login=true
xserver-allow-tcp=false" >> /etc/lightdm/lightdm.conf
</pre>

# LOGIN.DEFS Section /etc/login.defs
<pre>
1. Fix /etc/login.defs

PASS_MAX_DAYS	60
PASS_MIN_DAYS	10
PASS_WARN_AGE	7
ENCRYPT_METHOD  SHA512
LOGIN_RETRIES   3
LOG_OK_LOGINS   yes
</pre>

# File Permission Section
<pre>
Gavin List of chmods to do for system files:
#!/bin/bash
chmod -R 755 /etc/ssh
chmod -R 755 /etc/pam.d
chmod -R 755 /var/log
chmod -R 755 /etc/xinetd.d
chmod 400 /etc/cron.allow
chmod 000 /etc/shadow
chmod 400 /etc/shutdown.allow
chmod 400 /etc/cron.deny
chmod 600 /boot/grub/menu.lst
chmod 600 /etc/securetty
chmod 600 /etc/proftpd/ssl/proftpd.*
chmod 644 /etc/crontab
chmod 644 /etc/fstab
chmod 644 /etc/hosts.allow
chmod 644 /etc/hosts.deny
chmod 644 /etc/logrotate.conf
chmod 644 /etc/passwd
chmod 644 /etc/sysctl.conf
chmod 644 /etc/syslog.conf
chmod 644 /etc/udev/udev.conf
chmod 644 /etc/xinetd.conf
chmod 644 /var/log/lastlog
chmod 644 /var/log/messages
chmod 644 /var/log/wtmp
chmod 644 /etc/group
chmod 755 /etc/rc.d
chmod 755 /etc/security
chmod 755 /etc/sysconfig
chmod 02750 /bin/su
chmod 02750 /bin/sudo
chmod 02750 /bin/ping
chmod 02750 /sbin/ifconfig
chmod 02750 /usr/bin/w
chmod 02750 /usr/bin/who
chmod 02750 /usr/bin/locate
chmod 02750 /usr/bin/whereis
</pre>
# SUID Files Section
<pre>
1. find / -perm -4000 2>/dev/null
https://github.com/Anon-Exploiter/SUID3NUM (favorite script)
chmod 00775 path
chmdo a-st path
</pre>
# Bad Actors Section
<pre>
1. w | ss -plunt | netstat -ln | lsof -i :80
See anyone? kill -9. | pkill -9 -t pts/3

2. Run linpeas.sh. Checks for priv-esc vulns. (thanks Ravy)
<b>LinPEAS:</b> <a href="https://github.com/carlospolop/PEASS-ng/tree/master/linPEAS">linPEAS</a>

3. Check Crontab for Backdoors
/etc/crontab
/etc/cron.daily/cracklib-runtime
crontab -l
crontab -e
/var/spool/cron/crontabs
rm /var/spool/cron/crontabs/* (if not needed)
Delete any suspicious entries

4. Miscellaneous Files
/etc/rc.local
ls -lah in ~ home directory Check the .profile, .bashrc, .bash_logout, etc.
history - may show something interesting
grep -Ril "nc -l" / 2>/dev/null
grep -Ril "authorized_keys" /home 2>/dev/null (Are these your keys)

5. Run pspy32 in the background.
https://github.com/DominicBreuker/pspy/blob/master/README.md 
See if any suspicious activity happens. It will tell you the PID. 
Pretty nice, keeps out junk.
</pre>

# Stopping Services
<pre>
sudo service --status-all
service ssh stop
sudo service ssh status
service ssh start

systemctl list-units --type=service
systemctl list-units --type=service --state=active
systemctl status cups.service
sudo systemctl status cups.service
sudo systemctl stop cups.service
sudo systemctl start cups.service
</pre>

# SSH Hardening
<pre>
1. Secure SSH /etc/ssh.d/sshd_config
Protocol 2
PermitRootLogin = no
PubkeyAuthentication = no (if not using it, you can yes or no)
PermitEmptyPasswords = no
UsePAM = yes
UseDNS = no
AllowTcpForwarding no
Banner /etc/issue.net
X11Forwarding no
ForceCommand = Don't need this. Can be malicious. Delete.
Notes:https://man.openbsd.org/sshd_config
Reload Service after Changes: sudo service ssh restart


#!/bin/bash
sed -i -E 's/PasswordAuthentication.*/PasswordAuthentication no/g' /etc/ssh/sshd_config
sed -i 's/Protocol.*/Protocol 2/g' /etc/ssh/sshd_config
sed -i 's/PermitRootLogin.*/PermitRootLogin no/g' /etc/ssh/sshd_config
sed -i 's/X11Forwarding yes/X11Forwarding no/g' /etc/ssh/sshd_config
sed -i 's/UsePam no/UsePam yes/g' /etc/ssh/sshd_config
sed -i 's/RSAAuthentication no/RSAAuthentication yes/g' /etc/ssh/sshd_config
sed -i 's/PermitEmptyPasswords yes/PermitEmptyPasswords no/g' /etc/ssh/sshd_config
sed -i 's/StrictModes no/StrictModes yes/g' /etc/ssh/sshd_config
sed -i 's/LoginGraceTime.*/LoginGraceTime 60/g' /etc/ssh/sshd_config
sed -i 's/IgnoreRhosts no/IgnoreRhosts yes/g' /etc/ssh/sshd_config
sed -i 's/TCPKeepAlive yes/TCPKeepAlive no/g' /etc/ssh/sshd_config
sed -i 's/UsePrivilegeSeperation no/UsePrivilegeSeperation yes/g' /etc/ssh/sshd_config
sed -i 's/PubkeyAuthentication.*/PubkeyAuthentication yes/g' /etc/ssh/sshd_config
sed -i 's/PermitBlacklistedKeys yes/PermitBlacklistedKeys no/g' /etc/ssh/sshd_config
sed -i 's/HostbasedAuthentication yes/HostbasedAuthentication no/g' /etc/ssh/sshd_config
sed -i 's/PrintMotd yes/PrintMotd no/g' /etc/ssh/sshd_config
service ssh restart
service ssh reload
</pre>

# PostgreSQL Hardening
<pre>
<b>Basic Commands:</b>
sudo -u postgres psql || sudo -i -u postgres
psql
\l (List Databases)
\s (Command History)
\u (List Users)
\c template1 (Switch to DB)
\dt (List tables)
SELECT * FROM table_name;
\q
</pre>
<pre>
<b>/etc/postgresql/postgresql.conf</b>
ssl = true                                          
password_encryption = on

<b>/etc/postgresql/pg_hba.conf</b>
# Database administrative login by Unix domain socket
local   all             postgres                                peer

# TYPE  DATABASE        USER            ADDRESS                 METHOD

# "local" is for Unix domain socket connections only
local   all             all                                     peer
# IPv4 local connections:
host    all             all             127.0.0.1/32            md5
# IPv6 local connections:
#host    all             all             ::1/128                md5
# Allow replication connections from localhost, by a user with the
# replication privilege.
#local   replication     postgres                                peer
#host    replication     postgres        127.0.0.1/32            md5
#host    replication     postgres        ::1/128                 md5

- Change md5 to scram-sha-256 (if possible)
- Make sure to allow only 127.0.0.1/32
- Comment out IPv6 line
- Reload Service After Changes: sudo service postgresql restart

Corrected insecure permissions on PostgreSQL configuration files – 2%. The configuration files
for PostgreSQL on this system were viewable/editable by anyone on the system. Your team
would need to address that insecurity to gain points.
</pre>

# Samba Hardening
<pre>
sudo pdbedit -L -v
usershare allow guests = no
<a href="https://github.com/fcaviggia/hardening-script-el6/blob/master/config/smb.conf">https://github.com/fcaviggia/hardening-script-el6/blob/master/config/smb.conf</a>
Don't know alot about this. Config located in /etc/smb.conf

(Points last year for Samba)
Samba SMB1 protocol is disabled
Samba encryption is required
</pre>

# Web Hardening
<pre>
Run line 19-90 Martin Script. Run for Apache, PHP, config. 
</pre>

# Firefox Settings
<pre>
Settings -> Privacy and Security -> 
<b>Login and Passwords:</b>
- Ask to save logins and passwords for websites: Unchecked
- Show alerts about passwords for breached websites: Checked
<b>Permissions:</b>
- Block Pop-up windows: Checked
- Warn you when websites try to install add-ons: Checked
<b>Security:</b>
- Block Dangerous and deceptive content: Checked
- Block Dangerous Downloads: Checked
<b>Cookies and Site Data</b>
- Delete cookies and site data when Firefox is closed: Checked
</pre>

# Antivirus
<pre>
sudo apt-get install clamav
sudo freshclam
sudo clamscan
</pre>


# Sudo /etc/sudoers (/etc/sudoers Visudo)
<code>
1. Insecure permissions on Shadow File
sudo cat /etc/sudoers
sudo visudo 

##SUDO:
Line structure: `[user/group] [Hosts]=([allowed users]:[allowed groups]) [All commands]`
use % when defining groups

eg: 
`root ALL=(ALL:ALL) ALL`
`%sudo ALL=(ALL:ALL) ALL`

`NOPASSWD` allows the specified user or group to run as any user or group WITHOUT password auth.

eg:
`%haxors ALL=(NOPASSWD:ALL) ALL`

allows everyone in the haxors group to run any command as any user without password auth.


`NOEXEC` prevents commands from exectuting other commands:
eg:

`[username]	ALL = NOEXEC: /usr/bin/less`

prevents the specified user from running commands in less using `!command` (could be dangerous)

